# On the effect of word order on cross-lingual sentiment analysis

This experiment examines how neural networks trained for sentiment
analysis on source-language data are affected by differening word
order in the target-language.

## Models
1. BiLSTM
2. CNN
3. SVM

## Datasets
1. [OpeNER](http://journal.sepln.org/sepln/ojs/ojs/index.php/pln/article/view/4891)
2. [MultiBooked](http://www.lrec-conf.org/proceedings/lrec2018/summaries/217.html)

### Requirements

1. Python 3
2. sklearn  ```pip install -U scikit-learn```
3. Keras with Theano backend (could work with Tensorflow, but it hasn't been tested)
4. [H5py](http://docs.h5py.org/en/latest/build.html)

### Data you need
1. Word embeddings
2. Datasets (provided)


### Running the program

There are three steps to get the results mentioned in the paper.

## 1). Train the bilingual sentiment classifiers using the train_classifiers.sh script (you will have to change some parameters to your local setup).

```
./  train_classifiers.sh
```

## 2). Perform pre-reordering on the target-language data using the lexicon_and_random_prereordering.py and prereordering.py scripts (we have already provided these pre-reordered versions in the datasets directory).

## 3). Run the test_reordering script, which will output the results of that specific reordering.


```
python test_reordering.py [directory of data to test] -l [language (es, ca)] -c [classifier] -b [True=Binary, False=4-class]
```

For example, to test the BiLSTM on the binary Spanish dataset with no reordering, you would type:

```
python test_reordering.py datasets/original/es/raw -l es -c bilstm -b True
```


### Output

The results and a small error analysis text will be printed to the eval directory.

